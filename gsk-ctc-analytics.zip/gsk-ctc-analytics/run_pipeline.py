"""
GSK CTC Analytics – Full Pipeline Runner
Run all 4 phases sequentially with a single command:
    python run_pipeline.py
"""

import sys, os, time

def banner(text, color_code):
    print(f"\n\033[{color_code}m{'━'*55}\n  {text}\n{'━'*55}\033[0m")

def run_phase(module_path, label, color):
    banner(label, color)
    t0 = time.time()
    import importlib.util
    spec = importlib.util.spec_from_file_location("module", module_path)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    elapsed = time.time() - t0
    print(f"\n  ⏱  Completed in {elapsed:.1f}s")


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))

    print("\n" + "═"*55)
    print("  GSK CTC Analytics — Full Pipeline")
    print("  Author: Arqam Faiz Siddiqui")
    print("═"*55)

    run_phase("src/data_generator.py", "PHASE 1 — DATA DEVELOPMENT",   "94")
    run_phase("src/preprocessing.py",  "PHASE 2 — DATA PREPARATION",    "93")
    run_phase("src/kpi_engine.py",      "PHASE 3 — MODELLING",           "91")
    run_phase("src/visualizations.py",  "PHASE 4 — EVALUATION",          "92")

    print("\n" + "═"*55)
    print("  ✅  Pipeline complete!")
    print("  📊  Open dashboard/index.html in your browser")
    print("  📁  Charts saved to reports/figures/")
    print("═"*55 + "\n")
